const mongoose = require("mongoose");
const Comida = require("../models/comida.model");

module.exports.list = (req, res, next) => {
  res.render("comida", { comida });
};
