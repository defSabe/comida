const express = require("express");
const path = require("path");
const logger = require("morgan");

require("./config/db.config");

const app = express();

const port = 3000;
app.listen(port, () => {
  console.log(`Ready! Listening on port ${port}`);
});

const router = require("./config/routes.config");

app.use("/", router);

app.set("views", __dirname + "/views");
app.set("view engine", "hbs");
