const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  name: String,
  rating: Number,
  location: String,
  vegFriendly: Boolean,
});

const Comida = mongoose.model("Comida", schema);

module.exports = Comida;
