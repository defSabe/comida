const express = require("express");
const comida = require("../controllers/comida.controller");

const router = express.Router();

router.get("/", comida.list);

module.exports = router;
